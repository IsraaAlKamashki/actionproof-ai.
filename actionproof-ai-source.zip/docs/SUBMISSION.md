# Devpost submission draft

## Project name

ActionProof AI

## Category

Work & Productivity

## One-line description

An evidence-aware execution agent that turns meeting notes into source-grounded commitments, detects accountability gaps, verifies completion proof, and creates executive decision briefs.

## Inspiration

In business-performance work, the difficult part is rarely capturing more tasks. The difficult part is knowing what was truly agreed, who owns it, when it is due, what is blocked, and whether “complete” is supported by evidence. Teams often reconstruct this manually across notes, emails, trackers, and presentations. ActionProof was created to make that execution truth visible immediately.

## What it does

ActionProof accepts meeting notes or transcripts and uses GPT-5.6 to extract commitments into an execution control room. It identifies owners and deadlines, flags missing clarity and risk, defines the evidence required for completion, and links every result to its source quotation. Users can submit completion evidence through an evidence gate, after which verified status and metrics update. The same structured analysis becomes an executive brief that focuses leadership on decisions and intervention.

## How it was built

The product is a responsive TypeScript and React application with a server-side API route. The route calls the OpenAI Responses API using GPT-5.6 and strict structured output. The schema requires every commitment to include a title, owner, deadline, status, confidence level, proof requirement, and source quote. The API key remains server-side in a secret environment variable. A clearly labelled synthetic fallback keeps the workflow testable without misrepresenting demo output as live AI.

## How Codex was used

Codex was used throughout the core build session: shaping the product concept, designing the interaction model, implementing the responsive application, creating the GPT-5.6 structured-output route, testing the full browser journey, resolving issues, validating the production build, deploying checkpoints, and preparing documentation. Codex accelerated implementation while the product problem, priorities, proof model, and final decisions remained human-led.

## Challenges

The main design challenge was balancing automation with trust. A polished task list is not useful if the model invents an owner or date. ActionProof therefore makes missing information explicit, keeps source quotations visible, constrains the API output with a strict schema, and treats AI confidence as review context rather than certainty. A second challenge was designing evidence verification as a meaningful workflow rather than another checkbox.

## Accomplishments

- Complete workflow from notes to commitments, evidence, metrics, and executive brief
- Source traceability for every extracted action
- Explicit handling of missing ownership and deadlines
- Server-side GPT-5.6 structured analysis
- Responsive mobile and desktop interface
- Synthetic, privacy-safe demonstration content
- Graceful and clearly labelled demo fallback

## What was learned

AI productivity products create more value when they expose uncertainty instead of hiding it. Structured output makes downstream workflows reliable, but human review and source traceability are equally important. Completion itself also needs a definition: specifying the required proof changes the product from a task extractor into an execution-control system.

## What is next

Future versions could ingest documents and spreadsheets, connect commitments to email and collaboration tools, schedule reminders and escalations, maintain decision history, support organization-specific evidence policies, and create portfolio-level execution intelligence across initiatives.

## Links to add before submission

- Live project: https://actionproof-ai.israa-alkamshki.chatgpt.site
- GitHub repository: `[ADD URL]`
- Public YouTube demo: `[ADD URL]`
- Codex `/feedback` session ID: `[ADD ID]`
