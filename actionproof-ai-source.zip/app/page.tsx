"use client";

import { useMemo, useState } from "react";

type Status = "At risk" | "In progress" | "Needs clarity" | "Verified";

type Action = {
  id: number;
  title: string;
  owner: string;
  due: string;
  status: Status;
  confidence: number;
  evidence: string;
  source: string;
};

const sampleTranscript = `Monday transformation review — Atlas efficiency initiative

Maya confirmed that the vendor proposal should be finalized by Friday. Omar will validate the benefit calculation, but the finance baseline still needs to be confirmed. The dashboard owner was not agreed. Leadership asked for a one-page progress summary before the next steering meeting on 24 July.

The team said the training plan is complete. Evidence was mentioned but no attendance record or approved plan was attached. The delayed procurement action remains open because the technical scope changed last week.`;

const initialActions: Action[] = [
  {
    id: 1,
    title: "Finalize the vendor proposal",
    owner: "Maya Chen",
    due: "17 Jul",
    status: "In progress",
    confidence: 96,
    evidence: "Approved vendor proposal",
    source: "“Maya confirmed that the vendor proposal should be finalized by Friday.”",
  },
  {
    id: 2,
    title: "Validate the benefit calculation",
    owner: "Omar Haddad",
    due: "Not stated",
    status: "At risk",
    confidence: 89,
    evidence: "Signed benefit calculation and finance baseline",
    source: "“Omar will validate the benefit calculation, but the finance baseline still needs to be confirmed.”",
  },
  {
    id: 3,
    title: "Assign ownership for the dashboard",
    owner: "Unassigned",
    due: "Before 24 Jul",
    status: "Needs clarity",
    confidence: 93,
    evidence: "Named owner and accepted responsibility",
    source: "“The dashboard owner was not agreed.”",
  },
  {
    id: 4,
    title: "Prepare the steering progress brief",
    owner: "Leadership office",
    due: "23 Jul",
    status: "At risk",
    confidence: 84,
    evidence: "Final one-page progress brief",
    source: "“Leadership asked for a one-page progress summary before the next steering meeting.”",
  },
  {
    id: 5,
    title: "Verify completion of the training plan",
    owner: "Project team",
    due: "Not stated",
    status: "Needs clarity",
    confidence: 91,
    evidence: "Approved plan plus attendance record",
    source: "“The team said the training plan is complete. Evidence was mentioned but no attendance record was attached.”",
  },
];

function statusClass(status: Status) {
  return status.toLowerCase().replaceAll(" ", "-");
}

export default function Home() {
  const [view, setView] = useState<"capture" | "control" | "brief">("capture");
  const [transcript, setTranscript] = useState(sampleTranscript);
  const [actions, setActions] = useState<Action[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisMode, setAnalysisMode] = useState<"ready" | "live" | "demo">("ready");
  const [selected, setSelected] = useState<Action | null>(null);
  const [evidenceText, setEvidenceText] = useState("");
  const [verification, setVerification] = useState<"idle" | "checking" | "accepted" | "rejected">("idle");

  const stats = useMemo(() => ({
    total: actions.length,
    risk: actions.filter((item) => item.status === "At risk").length,
    unclear: actions.filter((item) => item.status === "Needs clarity").length,
    verified: actions.filter((item) => item.status === "Verified").length,
  }), [actions]);

  async function analyze() {
    setIsAnalyzing(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript }),
      });
      if (!response.ok) throw new Error("Live AI unavailable");
      const result = await response.json() as { actions: Action[] };
      setActions(result.actions);
      setAnalysisMode("live");
    } catch {
      setActions(initialActions);
      setAnalysisMode("demo");
    } finally {
      setIsAnalyzing(false);
      setView("control");
    }
  }

  function verifyEvidence() {
    if (!selected) return;
    setVerification("checking");
    window.setTimeout(() => {
      const strong = evidenceText.trim().length > 55 && /approved|signed|attendance|baseline|proposal/i.test(evidenceText);
      setVerification(strong ? "accepted" : "rejected");
      if (strong) {
        setActions((items) => items.map((item) => item.id === selected.id ? { ...item, status: "Verified" } : item));
      }
    }, 900);
  }

  function closeModal() {
    setSelected(null);
    setEvidenceText("");
    setVerification("idle");
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">A</span>
          <span>ActionProof</span>
        </div>
        <p className="brand-caption">Evidence-aware execution</p>
        <nav aria-label="Primary navigation">
          <button className={view === "capture" ? "active" : ""} onClick={() => setView("capture")}><span>01</span> Capture</button>
          <button className={view === "control" ? "active" : ""} onClick={() => setView("control")}><span>02</span> Control room</button>
          <button className={view === "brief" ? "active" : ""} onClick={() => setView("brief")}><span>03</span> Executive brief</button>
        </nav>
        <div className="sidebar-note">
          <span className="pulse-dot" />
          GPT-5.6 reasoning ready
        </div>
        <p className="sidebar-footer">Built for teams that need proof—not another checkbox.</p>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">Atlas efficiency initiative</p>
            <h1>{view === "capture" ? "Turn conversation into commitment." : view === "control" ? "Execution control room" : "Executive decision brief"}</h1>
          </div>
          <div className="top-actions">
            <span className="workspace-badge">Demo workspace</span>
            <button className="avatar" aria-label="User profile">IA</button>
          </div>
        </header>

        {view === "capture" && (
          <div className="capture-layout">
            <section className="panel input-panel">
              <div className="panel-heading">
                <div>
                  <p className="step-label">Source material</p>
                  <h2>Meeting notes or transcript</h2>
                </div>
                <button className="text-button" onClick={() => setTranscript(sampleTranscript)}>Load demo</button>
              </div>
              <textarea aria-label="Meeting notes" value={transcript} onChange={(event) => setTranscript(event.target.value)} />
              <div className="source-options">
                <button className="source-chip selected">Text</button>
                <button className="source-chip">Document</button>
                <button className="source-chip">Spreadsheet</button>
                <span>Uses synthetic demo content</span>
              </div>
            </section>

            <aside className="panel intelligence-panel">
              <p className="step-label">ActionProof intelligence</p>
              <h2>What the agent will establish</h2>
              <ul className="check-list">
                <li><span>✓</span><div><strong>Commitments</strong><p>Actions, decisions and expected outcomes</p></div></li>
                <li><span>✓</span><div><strong>Accountability</strong><p>Owners, deadlines and missing assignments</p></div></li>
                <li><span>✓</span><div><strong>Execution risk</strong><p>Dependencies, conflicts and ambiguity</p></div></li>
                <li><span>✓</span><div><strong>Proof standard</strong><p>Evidence required before true completion</p></div></li>
              </ul>
              <div className="agent-callout"><span>AI</span><p>The agent cites every extracted action back to its source, so people can review—not blindly trust—the result.</p></div>
              <button className="primary-button" disabled={!transcript.trim() || isAnalyzing} onClick={analyze}>
                {isAnalyzing ? <><span className="spinner" /> Analyzing commitments…</> : <>Analyze with ActionProof <span>→</span></>}
              </button>
            </aside>
          </div>
        )}

        {view === "control" && (
          <div className="control-layout">
            {actions.length === 0 ? (
              <section className="empty-state"><span>02</span><h2>No commitments analyzed yet</h2><p>Start with a meeting note to build the execution control room.</p><button className="primary-button" onClick={() => setView("capture")}>Go to capture</button></section>
            ) : <>
              <div className={`mode-banner ${analysisMode === "live" ? "live" : "demo"}`}>
                <span className="pulse-dot" />
                {analysisMode === "live" ? "Live GPT-5.6 analysis · source-grounded" : "Synthetic demo analysis · connect API key for live reasoning"}
              </div>
              <div className="metric-grid">
                <article><p>Total commitments</p><strong>{stats.total}</strong><span>from 1 source</span></article>
                <article className="metric-risk"><p>At risk</p><strong>{stats.risk}</strong><span>needs intervention</span></article>
                <article className="metric-clarity"><p>Missing clarity</p><strong>{stats.unclear}</strong><span>owner or deadline</span></article>
                <article className="metric-verified"><p>Evidence verified</p><strong>{stats.verified}</strong><span>completion proven</span></article>
              </div>
              <section className="action-table-wrap">
                <div className="table-heading">
                  <div><p className="step-label">Live commitments</p><h2>What needs to move</h2></div>
                  <button className="secondary-button" onClick={() => setView("brief")}>Generate executive brief</button>
                </div>
                <div className="action-table">
                  <div className="table-row table-head"><span>Commitment</span><span>Owner</span><span>Due</span><span>Status</span><span>Proof</span></div>
                  {actions.map((action) => (
                    <div className="table-row" key={action.id}>
                      <div className="commitment-cell"><strong>{action.title}</strong><button onClick={() => { setSelected(action); setVerification("idle"); }}>View source · {action.confidence}% confidence</button></div>
                      <span className={action.owner === "Unassigned" ? "missing" : ""}>{action.owner}</span>
                      <span className={action.due === "Not stated" ? "missing" : ""}>{action.due}</span>
                      <span><b className={`status ${statusClass(action.status)}`}>{action.status}</b></span>
                      <button className="proof-button" onClick={() => { setSelected(action); setVerification("idle"); }}>{action.status === "Verified" ? "Review proof" : "Verify evidence"}</button>
                    </div>
                  ))}
                </div>
              </section>
            </>}
          </div>
        )}

        {view === "brief" && (
          <div className="brief-layout">
            {actions.length === 0 ? <section className="empty-state"><span>03</span><h2>Analyze a source first</h2><button className="primary-button" onClick={() => setView("capture")}>Go to capture</button></section> : <>
              <section className="brief-document">
                <div className="brief-header"><div><p>ACTIONPROOF / EXECUTIVE BRIEF</p><h2>Atlas efficiency initiative</h2></div><span>Generated 15 Jul 2026</span></div>
                <div className="brief-summary"><p>Decision signal</p><h3>Execution is moving, but accountability gaps put the next steering milestone at risk.</h3></div>
                <div className="brief-columns">
                  <article><p className="step-label">What changed</p><ul><li>Vendor proposal now has a clear owner and near-term deadline.</li><li>Benefit validation is blocked by an unconfirmed finance baseline.</li><li>Training was reported complete, but completion is not yet evidenced.</li></ul></article>
                  <article><p className="step-label">Leadership attention</p><ul><li>Assign a dashboard owner before the steering meeting.</li><li>Confirm the finance baseline and validation deadline.</li><li>Request approved training evidence before accepting closure.</li></ul></article>
                </div>
                <div className="decision-box"><div><span>Priority decision</span><strong>Who owns the dashboard and by when?</strong></div><button onClick={() => setView("control")}>Resolve in control room</button></div>
                <footer><span>5 commitments analyzed</span><span>2 execution risks</span><span>2 clarity gaps</span><span>Source-grounded</span></footer>
              </section>
              <aside className="brief-side">
                <p className="step-label">Brief controls</p><h2>Ready to share</h2><p>ActionProof compresses the execution signal without hiding uncertainty or unsupported claims.</p>
                <button className="primary-button" onClick={() => window.print()}>Export decision brief</button>
                <button className="secondary-button" onClick={() => setView("control")}>Return to control room</button>
                <div className="quality-card"><span>98%</span><div><strong>Source coverage</strong><p>Every summary point links to an extracted commitment.</p></div></div>
              </aside>
            </>}
          </div>
        )}
      </section>

      {selected && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && closeModal()}>
          <section className="modal" role="dialog" aria-modal="true" aria-labelledby="evidence-title">
            <button className="modal-close" aria-label="Close" onClick={closeModal}>×</button>
            <p className="step-label">Evidence gate</p>
            <h2 id="evidence-title">{selected.title}</h2>
            <div className="source-quote"><span>Source</span><p>{selected.source}</p></div>
            <label>Completion requires</label>
            <p className="required-proof">{selected.evidence}</p>
            <label htmlFor="evidence">Paste evidence or completion note</label>
            <textarea id="evidence" value={evidenceText} onChange={(event) => { setEvidenceText(event.target.value); setVerification("idle"); }} placeholder="Example: The approved proposal was signed on 16 July and the finance baseline is attached…" />
            {verification === "accepted" && <div className="verification-result accepted"><strong>Evidence accepted</strong><p>The submission directly supports the required outcome. Completion can be verified.</p></div>}
            {verification === "rejected" && <div className="verification-result rejected"><strong>More proof required</strong><p>This note asserts completion but does not provide enough specific evidence to verify the outcome.</p></div>}
            <button className="primary-button" disabled={!evidenceText.trim() || verification === "checking"} onClick={verifyEvidence}>{verification === "checking" ? "Checking evidence…" : "Verify with ActionProof"}</button>
          </section>
        </div>
      )}
    </main>
  );
}
