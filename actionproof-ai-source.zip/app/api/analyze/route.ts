import { NextResponse } from "next/server";

const schema = {
  type: "object", additionalProperties: false, required: ["actions"],
  properties: { actions: { type: "array", minItems: 1, maxItems: 12, items: {
    type: "object", additionalProperties: false,
    properties: {
      title: { type: "string" }, owner: { type: "string" }, due: { type: "string" },
      status: { type: "string", enum: ["At risk", "In progress", "Needs clarity"] },
      confidence: { type: "integer", minimum: 0, maximum: 100 },
      evidence: { type: "string" }, source: { type: "string" },
    },
    required: ["title", "owner", "due", "status", "confidence", "evidence", "source"],
  } } },
};

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "AI connection is not configured." }, { status: 503 });
  const body = await request.json().catch(() => null) as { transcript?: string } | null;
  const transcript = body?.transcript?.trim();
  if (!transcript || transcript.length > 30_000) return NextResponse.json({ error: "Invalid source length." }, { status: 400 });

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "gpt-5.6",
      input: [
        { role: "system", content: [{ type: "input_text", text: "You are ActionProof, an evidence-aware execution analyst. Extract only commitments supported by the source. Use 'Unassigned' or 'Not stated' when absent. Mark ambiguity as 'Needs clarity', blocked or endangered work as 'At risk', otherwise 'In progress'. Define concrete proof required before completion. Include a short verbatim source quote. Never invent names, dates, claims, or evidence." }] },
        { role: "user", content: [{ type: "input_text", text: transcript }] },
      ],
      text: { format: { type: "json_schema", name: "actionproof_analysis", strict: true, schema } },
    }),
  });
  const result = await response.json() as { output_text?: string; error?: { message?: string } };
  if (!response.ok || !result.output_text) return NextResponse.json({ error: result.error?.message || "AI analysis failed." }, { status: 502 });
  try {
    const parsed = JSON.parse(result.output_text) as { actions: Array<Record<string, unknown>> };
    return NextResponse.json({ actions: parsed.actions.map((action, index) => ({ ...action, id: index + 1 })) });
  } catch {
    return NextResponse.json({ error: "AI returned an invalid analysis." }, { status: 502 });
  }
}
